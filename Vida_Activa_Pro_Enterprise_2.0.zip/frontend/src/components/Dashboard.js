
import React from "react";
import { Line } from "react-chartjs-2";
import { motion } from "framer-motion";

const Dashboard = () => {
  const data = {
    labels: ["Lun","Mar","Mie","Jue","Vie"],
    datasets: [{
      label: "Minutos Actividad Física",
      data: [30,45,20,60,50]
    }]
  };

  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} transition={{duration:1}}>
      <div style={{maxWidth:"600px",margin:"auto"}}>
        <Line data={data}/>
      </div>
    </motion.div>
  );
};

export default Dashboard;
