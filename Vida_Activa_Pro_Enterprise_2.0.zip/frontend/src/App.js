
import React from "react";
import Dashboard from "./components/Dashboard";

function App() {
  return (
    <div style={{background:"linear-gradient(135deg,#1b5e20,#43a047,#81c784)",minHeight:"100vh",color:"white"}}>
      <h1 style={{textAlign:"center",padding:"20px"}}>🌿 Vida Activa Pro Enterprise</h1>
      <Dashboard/>
    </div>
  );
}

export default App;
