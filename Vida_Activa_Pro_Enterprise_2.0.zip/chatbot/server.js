
import express from "express";
const app = express();
app.use(express.json());

app.post("/chat",(req,res)=>{
    const mensaje = req.body.mensaje;
    res.json({respuesta:`🌿 Consejo saludable: Mantente activo y bebe agua 💧`});
});

app.listen(3000,()=>console.log("Chatbot IA activo"));
