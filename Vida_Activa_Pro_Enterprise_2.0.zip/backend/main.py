
from fastapi import FastAPI
from sklearn.ensemble import RandomForestClassifier
import numpy as np

app = FastAPI()

# Dummy training data
X = np.array([
    [10,2,5],
    [15,1,7],
    [8,4,3],
    [12,2,6],
    [16,1,8]
])
y = np.array([0,0,1,0,0])

model = RandomForestClassifier()
model.fit(X,y)

@app.get("/")
def root():
    return {"status":"ML Enterprise Running"}

@app.post("/predict")
def predict(data: dict):
    features = np.array([[data["edad"],data["pantalla"],data["actividad"]]])
    prediction = model.predict(features)
    return {"riesgo_sedentario": int(prediction[0])}
